


<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8"> 
        
        <!-- The "charset" attribute specifies the character encoding for the HTML document.
            It covers almost all the characters and symbols in the world-->
        <title> Home page/ IMAGE OVERLAY HOVER EFFECT WITH CSS | CSS IMAGE HOVER EFFECT </title>

        <link rel="stylesheet" href="home-style.css">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.2/animate.min.css">
        
        <style> 
            .container
            {
                background-image: url("image-items/fx6.png");
            }
            
        </style>


    </head>
    <body>
        <script> alert ("Welcome to my website!\n Enjoy!🔥😎"); </script>
        <div class="container">
            <div class="nav-wrapper">
                <div class="left-side">
                    <div class="nav-link-wrapper">
                       <a href="#">Home</a>
                    </div>

                    <div class="nav-link-wrapper">   
                       <a href="#">About Us</a>
                    </div> 

                    <div class="nav-link-wrapper">   
                        <a href="login.php">Login</a>
                     </div> 
                     <div class="nav-link-wrapper">   
                        <a href="signup.php">Signup</a>
                    </div> 

                    <div class="nav-link-wrapper">   
                       <a href="#">Learn</a>
                    </div>

                </div>   
           
                <div class="right-side">
                    <div class="brand">
                       <div style="font-size: xx-large;">TEAM RO </div>
                    </div>
                </div>
            
            </div>

            
            <div class ="creators">
                <div class="text"> MEET THE TEAM</div>
            </div>
            <div class="team-area">
                
                <div class="single-team">
                    <img src="image-items/1.jpg" alt="" height="400px" width="400px" >
                    <div class="team-text">
                        <h2> Ramsey Phile </h2>
                        
                        <p>Fx analyst / Digital marketer / Artist </p>
                        <p>
                            
                            <a onclick= "alert('Are you sure \n you want to go to \n ramseys github account?')" href="https://github.com/rraammsseeyy"><i class="fa fa-github"></i> </a>
                            <a href="https://www.linkedin.com/in/ransom-philemon-1829651b9/"><i class="fa fa-linkedin"></i> </a>
                            <a href="https://www.instagram.com/ramseys_arts/"><i class="fa fa-instagram"></i> </a>
                        </p>
                    </div>
                </div>
                <div class="single-team">
                    <img src="image-items/2.jpg" alt="" height="400px" width="400px">
                    <div class="team-text">
                        <h2> Osas </h2>
                        <p>Finicial Advisor / Sales Manager</p>
                        <p>
                            <a href="#"><i class="fa fa-facebook"></i> </a>
                            <a href="#"><i class="fa fa-twitter"></i> </a>
                            
                            <a href="https://www.instagram.com/boboofabuja/"><i class="fa fa-instagram"></i> </a>
                        </p>
                    </div>
                </div>
                <div class="single-team">
                    <img src="image-items/3.jpg" alt="" height="400px" width="400px"
                    >
                    <div class="team-text">
                        <h2> Vickkie Phile </h2>
                        <p>Content writer / Transportation engineer  </p>
                        <p>
                            
                            <a href="#"><i class="fa fa-twitter"></i> </a>
                            
                            <a href="https://www.instagram.com/vee.philemon/"><i class="fa fa-instagram"></i> </a>
                        </p>
                    </div>
                </div>
            </div>

            <div class="started">
                <div class="text">
                    <h2>Let's get you started! <br/>
                        TEAM RO will put you on your path to financial freedom! <br/>
                    
                        Choose where to get started!

                    </h2>
                    
                        
                </div>
            </div>
            <div class="workspace">
                
                <div class="single-workspace">
                    <img src="image-items/fx1.jpg" alt="" >
                    <div class="head-text">
                        
                        
                        <div class="text">
                            <h2 >FX</h2>
                            <p>Learn how to trade forex in the financial market</p>
                        </div>
                    </div>
        
                </div>
            
            </div>

            <div class="workspace">
                <div class="single-workspace"> 
                    <img src="image-items/crypto2.jpg" alt="",  >
                    <div class="head-text">
                        
                        
                        <div class="text">
                            <h2 >CRYPTO</h2>
                            <p>Learn how to trade crypto in the financial market</p>
                        </div>
                    </div>
                </div>
                
            </div>
            <div class="workspace">
                <div class="single-workspace"> 
                    <img src="image-items/nba.jpeg" alt="", height="1500px" width="1500px" >
                    <div class="head-text">
                        
                        
                        <div class="text">
                            <h2 >ART / Graphic design
                            </h2>
                            <p>Learn how to create art</p>
                        </div>
                    </div>
                </div>
                
            </div>
            
            <div class="workspace">
                <div class="single-workspace"> 
                    <img src="image-items/fifa-22b.jpg.png" alt="", height="1500px" width="1500px" >
                    <div class="head-text">
                        
                        
                        <div class="text">
                            <h2 >FIFA 22 GAMING</h2>
                            <p>Learn how to be a pro at fifa and dominate your friends🔥🔥</p>
                        </div>
                    </div>
                </div>
                
            </div>

            <!-- <div class="workspace">
                <div class="single-workspace"> 
                    <img src="image-items/portfolio4.jpg" alt="",  >
                    <div class="head-text">
                        <a href="stock.html"> Click here to know more</a>
                        <div class="text">
                            <h2 >STOCK MARKET</h2>
                            <p>Learn how to trade stocks and profit from it.</p>
                        </div>
                    </div>
                </div>
                
            </div>

            <div class="workspace">
                <div class="single-workspace"> 
                    <img src="image-items/portfolio12.jpg" alt="",  >
                    <div class="head-text">
                        <a href="graphic.html"> Click here to know more</a>
                        <div class="text">
                            <h2 >GRAPHIC DESIGN </h2>
                            <p>Learn how to make money of graphic designing</p>
                        </div>
                    </div>
                </div>
                
            </div> -->
            
            
                
            

            
        
            
                
            
            
        </div>
        

    </body>


</html>

