-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jan 25, 2022 at 12:53 PM
-- Server version: 5.7.36
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `teamro`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`ID`, `username`, `email`, `password`) VALUES
(6, 'dfxcghjb', 'fcgyhjb@gmail.com', '123123gvhjb'),
(5, 'rvhjbk', 'ghvjb@gmail.com', '123123fugy'),
(4, 'rootghj', 'fghjk@gfhjk.ccj', '123123ghjk'),
(7, 'ghfyj', 'ytfugikh@gmail.com', '123123hgk'),
(8, 'hfgvj', 'fghvjbk@gmail.com', '123123cghvj'),
(9, 'ramsey', 'ramseyphile6@gmail.com', 'myname'),
(10, 'bobo', 'boboofabuja@gmail.com', 'dtyfugiho'),
(11, 'joy', 'joyjkl@gmail.com', '123123gtfu'),
(12, 'hey@gmail.com', 'me@gmail.com', 'hhghgh'),
(13, 'amina', 'amina@gmail.com', 'aminasucks'),
(14, 'umardam', 'adam@gmail.com', '123123dusgv'),
(15, 'rootjk', 'fda@gmail.com', 'jkbg');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
